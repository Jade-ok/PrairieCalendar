// utils.js
// TODO: Shared helper functions (date parsing, formatting, UID helpers, etc.)

export function noop() {}